# Nova — AI Study Assistant

A responsive dark-themed study assistant built with HTML, CSS, JavaScript, Node.js, Express, and the Gemini API.

## Features

- **AI tutor chat** with recent conversation context
- **Notes summarizer** with quick, balanced, and detailed styles
- **Quiz generator** with 3–10 multiple-choice questions, three difficulty levels, scoring, and explanations
- Responsive layout for desktop and mobile
- Server-side API key storage (the key is never placed in browser JavaScript)

## Requirements

- Node.js 20 or newer recommended
- A Gemini API key from Google AI Studio: https://aistudio.google.com/apikey
- Internet access for Gemini API requests

## Run locally on Windows

1. Extract the ZIP and open the `ai-study-assistant` folder in VS Code.
2. Open the VS Code terminal (`Terminal → New Terminal`).
3. Install dependencies:

   ```powershell
   npm install
   ```

4. Create your private environment file by copying `.env.example` to `.env`:

   ```powershell
   Copy-Item .env.example .env
   ```

5. Open `.env` and replace `put_your_gemini_api_key_here` with your own key. Do not add quotes unless needed and do not share this file.
6. Start the server:

   ```powershell
   npm start
   ```

7. Open http://localhost:3000 in your browser.

Keep the terminal running while you use the app. Do not open `public/index.html` directly with `file://`; use the local server URL.

## Run in development mode

```powershell
npm run dev
```

## API endpoints

- `GET /api/health` — reports whether the key is configured
- `POST /api/chat` — `{ "message": "...", "history": [] }`
- `POST /api/summarize` — `{ "text": "...", "style": "balanced" }`
- `POST /api/quiz` — `{ "topic": "...", "count": 5, "difficulty": "medium" }`

## API key safety

- Keep `GEMINI_API_KEY` only in `.env` on the server.
- `.env` is excluded by `.gitignore`; commit `.env.example`, never `.env`.
- Never paste the key into `public/script.js`, `public/index.html`, screenshots, or public repositories.
- If a key is accidentally exposed, revoke it and create a new one.
- For a public deployment, use the hosting provider's secret/environment-variable settings and add rate limiting, authentication where appropriate, and usage limits before sharing widely.

## Troubleshooting

- **“API key is not configured”**: check that `.env` is in the project root and the variable is named exactly `GEMINI_API_KEY`; restart the server after changing it.
- **API request failed / quota**: check your key, Gemini API availability, account limits, and internet connection.
- **PowerShell blocks npm scripts**: use the VS Code terminal set to Command Prompt, or run `npm.cmd install` and `npm.cmd start`.
- **Port already in use**: set `PORT=3001` in `.env`, restart, and visit http://localhost:3001.

## Tech stack

HTML5 · CSS3 · Vanilla JavaScript · Node.js · Express · Google Gemini API
