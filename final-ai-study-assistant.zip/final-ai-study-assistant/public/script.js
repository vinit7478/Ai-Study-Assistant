const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const views = {
  chat: { element: $("#chatView"), title: "AI tutor" },
  summarizer: { element: $("#summarizerView"), title: "Note summarizer" },
  quiz: { element: $("#quizView"), title: "Quiz generator" }
};

let chatHistory = [];
let lastSummary = "";
let currentQuiz = [];
let quizAnswers = {};
let quizSubmitted = false;
let toastTimer;

function toast(message) {
  const element = $("#toast");
  element.textContent = message;
  element.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove("show"), 3000);
}

async function apiRequest(path, body) {
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data;
}

async function checkHealth() {
  const status = $("#engineStatus");
  const card = status.closest(".status-card");
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    if (data.configured) {
      status.textContent = "Connected · " + data.model;
      card.classList.add("connected");
    } else {
      status.textContent = "API key needed";
      card.classList.remove("connected");
    }
  } catch {
    status.textContent = "Server unavailable";
    card.classList.remove("connected");
  }
}

function switchView(name) {
  if (!views[name]) return;
  Object.entries(views).forEach(([key, view]) => view.element.classList.toggle("active", key === name));
  $$(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.view === name));
  $("#pageName").textContent = views[name].title;
  $("#sidebar").classList.remove("open");
}

$$(".nav-item").forEach(button => button.addEventListener("click", () => switchView(button.dataset.view)));
$("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));

function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function formatText(text) {
  // Escape HTML first, then apply a small safe Markdown-like subset.
  return escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/^### (.+)$/gm, "<strong>$1</strong>")
    .replace(/^## (.+)$/gm, "<strong>$1</strong>")
    .replace(/^- (.+)$/gm, "• $1")
    .replace(/\n/g, "<br>");
}

function addMessage(role, text, options = {}) {
  const wrapper = document.createElement("div");
  wrapper.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "S" : "✦";
  const body = document.createElement("div");
  body.className = "message-body";
  if (options.loading) {
    body.innerHTML = '<span class="typing-dots"><i></i><i></i><i></i></span>';
    wrapper.dataset.loading = "true";
  } else {
    body.innerHTML = formatText(text);
  }
  wrapper.append(avatar, body);
  $("#messages").append(wrapper);
  wrapper.scrollIntoView({ behavior: "smooth", block: "nearest" });
  return wrapper;
}

function resetChat() {
  chatHistory = [];
  $("#messages").replaceChildren();
  $("#welcome").style.display = "";
  $("#chatInput").value = "";
  $("#chatInput").focus();
}

$("#newChatBtn").addEventListener("click", resetChat);

async function sendChatMessage(message) {
  const text = message.trim();
  if (!text) return;
  $("#welcome").style.display = "none";
  addMessage("user", text);
  const priorHistory = chatHistory.slice(-8);
  chatHistory.push({ role: "user", text });
  const loading = addMessage("model", "", { loading: true });
  $("#sendBtn").disabled = true;
  try {
    const data = await apiRequest("/api/chat", { message: text, history: priorHistory });
    loading.remove();
    addMessage("model", data.answer);
    chatHistory.push({ role: "model", text: data.answer });
    chatHistory = chatHistory.slice(-10);
  } catch (error) {
    loading.remove();
    addMessage("model", `I couldn't answer that just now. ${error.message}`);
    toast(error.message);
  } finally {
    $("#sendBtn").disabled = false;
    $("#chatInput").focus();
  }
}

$("#chatForm").addEventListener("submit", event => {
  event.preventDefault();
  const input = $("#chatInput");
  const message = input.value.trim();
  if (!message) return;
  input.value = "";
  input.style.height = "auto";
  sendChatMessage(message);
});

$("#chatInput").addEventListener("input", event => {
  event.target.style.height = "auto";
  event.target.style.height = `${Math.min(event.target.scrollHeight, 160)}px`;
});
$("#chatInput").addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    $("#chatForm").requestSubmit();
  }
});
$$("[data-prompt]").forEach(button => button.addEventListener("click", () => {
  const prompt = button.dataset.prompt;
  switchView("chat");
  sendChatMessage(prompt);
}));
document.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    resetChat();
  }
});

$("#notesInput").addEventListener("input", event => {
  $("#charCount").textContent = `${event.target.value.length.toLocaleString()} characters`;
});

$("#summarizeBtn").addEventListener("click", async () => {
  const text = $("#notesInput").value.trim();
  if (text.length < 20) {
    toast("Paste at least 20 characters of notes first.");
    $("#notesInput").focus();
    return;
  }
  const button = $("#summarizeBtn");
  button.disabled = true;
  button.innerHTML = '<span class="loading-label">✦ Working on your summary…</span>';
  $("#summaryOutput").textContent = "Reading your notes and organizing the key ideas…";
  $("#copySummary").disabled = true;
  try {
    const data = await apiRequest("/api/summarize", { text, style: $("#summaryStyle").value });
    lastSummary = data.summary;
    $("#summaryOutput").textContent = lastSummary;
    $("#copySummary").disabled = false;
  } catch (error) {
    $("#summaryOutput").textContent = error.message;
    toast(error.message);
  } finally {
    button.disabled = false;
    button.innerHTML = '<span>✦</span> Summarize my notes <span class="btn-arrow">→</span>';
  }
});

$("#copySummary").addEventListener("click", async () => {
  if (!lastSummary) return;
  try {
    await navigator.clipboard.writeText(lastSummary);
    toast("Summary copied to clipboard.");
  } catch {
    toast("Clipboard access was blocked by your browser.");
  }
});

$("#quizForm").addEventListener("submit", async event => {
  event.preventDefault();
  const topic = $("#quizTopic").value.trim();
  if (!topic) return;
  const button = $("#generateQuizBtn");
  button.disabled = true;
  button.innerHTML = '<span class="loading-label">✦ Building your quiz…</span>';
  $("#quizArea").innerHTML = '<div class="empty-state"><div class="empty-art">✧</div><h3>Preparing your challenge</h3><p>Nova is writing questions and checking the answer choices.</p></div>';
  try {
    const data = await apiRequest("/api/quiz", {
      topic,
      count: Number($("#quizCount").value),
      difficulty: $("#quizDifficulty").value
    });
    currentQuiz = data.questions;
    quizAnswers = {};
    quizSubmitted = false;
    renderQuiz();
    $("#quizArea").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    $("#quizArea").textContent = error.message;
    toast(error.message);
  } finally {
    button.disabled = false;
    button.innerHTML = '<span>✦</span> Generate my quiz <span class="btn-arrow">→</span>';
  }
});

function renderQuiz() {
  const area = $("#quizArea");
  area.replaceChildren();
  currentQuiz.forEach((question, questionIndex) => {
    const card = document.createElement("article");
    card.className = "quiz-card";
    const progress = document.createElement("div");
    progress.className = "quiz-progress";
    progress.textContent = `QUESTION ${String(questionIndex + 1).padStart(2, "0")} / ${String(currentQuiz.length).padStart(2, "0")}`;
    const title = document.createElement("h3");
    title.className = "quiz-question";
    title.textContent = question.question;
    card.append(progress, title);
    question.options.forEach((option, optionIndex) => {
      const label = document.createElement("label");
      label.className = "quiz-option";
      const radio = document.createElement("input");
      radio.type = "radio";
      radio.name = `question-${questionIndex}`;
      radio.value = String(optionIndex);
      radio.checked = quizAnswers[questionIndex] === optionIndex;
      radio.disabled = quizSubmitted;
      radio.addEventListener("change", () => { quizAnswers[questionIndex] = optionIndex; });
      const span = document.createElement("span");
      span.textContent = option;
      label.append(radio, span);
      if (quizSubmitted && optionIndex === question.answer) label.classList.add("correct");
      else if (quizSubmitted && quizAnswers[questionIndex] === optionIndex && optionIndex !== question.answer) label.classList.add("wrong");
      card.append(label);
    });
    if (quizSubmitted) {
      const explanation = document.createElement("p");
      explanation.className = "quiz-explanation";
      explanation.textContent = `Explanation: ${question.explanation || "Review the correct answer and the concept behind it."}`;
      card.append(explanation);
    }
    area.append(card);
  });

  if (!quizSubmitted) {
    const submit = document.createElement("button");
    submit.className = "primary-btn";
    submit.textContent = "Check my answers  →";
    submit.addEventListener("click", submitQuiz);
    area.append(submit);
  } else {
    const score = currentQuiz.reduce((total, question, index) => total + (quizAnswers[index] === question.answer ? 1 : 0), 0);
    const results = document.createElement("div");
    results.className = "quiz-results";
    const heading = document.createElement("h3");
    heading.textContent = score === currentQuiz.length ? "Brilliant work!" : score >= currentQuiz.length * 0.6 ? "You're making progress!" : "Every attempt teaches you something.";
    const paragraph = document.createElement("p");
    paragraph.innerHTML = `You scored <strong>${score} / ${currentQuiz.length}</strong>. Review the explanations above, then try again.`;
    const actions = document.createElement("div");
    actions.className = "quiz-actions";
    const retry = document.createElement("button");
    retry.className = "secondary-btn";
    retry.textContent = "Try this quiz again";
    retry.addEventListener("click", () => { quizAnswers = {}; quizSubmitted = false; renderQuiz(); });
    const newQuiz = document.createElement("button");
    newQuiz.className = "primary-btn";
    newQuiz.textContent = "Create a new quiz";
    newQuiz.addEventListener("click", () => { $("#quizTopic").focus(); $("#quizForm").scrollIntoView({ behavior: "smooth" }); });
    actions.append(retry, newQuiz);
    results.append(heading, paragraph, actions);
    area.append(results);
  }
}

function submitQuiz() {
  if (Object.keys(quizAnswers).length < currentQuiz.length) {
    toast("Answer every question before checking your score.");
    return;
  }
  quizSubmitted = true;
  renderQuiz();
}

$("#themeInfo").addEventListener("click", () => { $("#aboutModal").hidden = false; });
$("#closeModal").addEventListener("click", () => { $("#aboutModal").hidden = true; });
$("#gotItBtn").addEventListener("click", () => { $("#aboutModal").hidden = true; });
$("#aboutModal").addEventListener("click", event => {
  if (event.target === $("#aboutModal")) $("#aboutModal").hidden = true;
});

checkHealth();
