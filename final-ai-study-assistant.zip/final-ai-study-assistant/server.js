import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT) || 3000;
// Gemini 3.5 Flash was the fastest consistent response in recent live checks.
// Minimal thinking keeps study answers quick; all configured fallbacks support it.
const MODEL = process.env.GEMINI_MODEL?.trim() || "gemini-3.5-flash";
const FALLBACK_MODELS = [
  MODEL,
  "gemini-3.6-flash",
  "gemini-3.5-flash-lite"
].filter((model, index, list) => list.indexOf(model) === index);
// Try the preferred model once more after a short pause. Gemini 503s are often
// short capacity spikes, and this avoids making the student resend a question.
const MODEL_ATTEMPTS = [...FALLBACK_MODELS, MODEL];
const MODEL_TIMEOUT_MS = 7_000;
const apiKey = process.env.GEMINI_API_KEY?.trim();
const ai = apiKey && apiKey !== "put_your_gemini_api_key_here"
  ? new GoogleGenAI({ apiKey })
  : null;

app.disable("x-powered-by");
app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

function cleanText(value, maxLength = 12000) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

async function generateWithTimeout(request, model) {
  let timer;
  try {
    return await Promise.race([
      request,
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          const error = new Error(`The ${model} request timed out.`);
          error.status = 504;
          reject(error);
        }, MODEL_TIMEOUT_MS);
      })
    ]);
  } finally {
    clearTimeout(timer);
  }
}

function requireAI(_req, res, next) {
  if (!ai) {
    return res.status(503).json({
      error: "Gemini API key is not configured. Copy .env.example to .env, add GEMINI_API_KEY, and restart the server."
    });
  }
  next();
}

async function generateText(prompt, systemInstruction) {
  let lastError;
  for (let index = 0; index < MODEL_ATTEMPTS.length; index += 1) {
    const model = MODEL_ATTEMPTS[index];
    try {
      const response = await generateWithTimeout(
        ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            systemInstruction,
            temperature: 0.5,
            maxOutputTokens: 900,
            thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL }
          }
        }),
        model
      );
      return response.text?.trim() || "I couldn't generate a response. Please try again.";
    } catch (error) {
      lastError = error;
      const status = Number(error?.status);
      const detail = String(error?.message || "").toLowerCase();
      const looksLikeExhaustedQuota = status === 429 &&
        /(daily quota|billing|quota exceeded|check your plan|limit: 0)/i.test(detail);
      // A 429 may apply to just one model, so try the next model. Avoid extra
      // requests when Gemini explicitly says the account quota is exhausted.
      if (looksLikeExhaustedQuota) throw error;
      if (![429, 503, 504].includes(status)) throw error;
      if (index < MODEL_ATTEMPTS.length - 1) {
        await new Promise(resolve => setTimeout(resolve, status === 429 ? 250 : 1_000));
      }
    }
  }
  throw lastError;
}

function sendAIError(res, context, error) {
  console.error(`${context} API error:`, error?.message || error);
  const status = Number(error?.status);
  if (status === 401 || status === 403) {
    return res.status(502).json({ error: "Gemini rejected the API key. Check GEMINI_API_KEY and restart the server." });
  }
  if (status === 429) {
    return res.status(429).json({ error: "Gemini's rate or usage limit was reached for the available models. Wait briefly and try again; if it continues, check your Google AI Studio quota and billing limits." });
  }
  if (status === 503) {
    return res.status(503).json({ error: "Gemini is temporarily busy. Please wait a minute and try again." });
  }
  if (status === 504) {
    return res.status(504).json({ error: "The AI service took too long to respond. Please try again." });
  }
  return res.status(502).json({ error: "The AI request failed. Check your API key, network connection, and Gemini quota, then try again." });
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(ai), model: MODEL });
});

app.post("/api/chat", requireAI, async (req, res) => {
  const message = cleanText(req.body?.message, 5000);
  if (!message) return res.status(400).json({ error: "Please enter a question." });
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-8) : [];
  const safeHistory = history
    .filter(item => item && ["user", "model"].includes(item.role) && typeof item.text === "string")
    .map(item => `${item.role === "user" ? "Student" : "Assistant"}: ${cleanText(item.text, 1500)}`)
    .filter(Boolean)
    .join("\n");
  try {
    const answer = await generateText(
      `${safeHistory ? `Recent conversation:\n${safeHistory}\n\n` : ""}Student's latest message:\n${message}`,
      "You are Nova, a friendly AI study assistant. Explain concepts accurately and clearly. Use short headings and bullets when useful. If you are uncertain, say so rather than inventing facts."
    );
    res.json({ answer });
  } catch (error) {
    sendAIError(res, "Chat", error);
  }
});

app.post("/api/summarize", requireAI, async (req, res) => {
  const text = cleanText(req.body?.text, 12000);
  const style = cleanText(req.body?.style, 30) || "balanced";
  if (text.length < 20) return res.status(400).json({ error: "Paste at least 20 characters of notes to summarize." });
  const styles = {
    short: "Make a very concise summary in 3–5 bullet points.",
    balanced: "Create a clear summary with a short overview, key points, and important terms.",
    detailed: "Create detailed study notes with headings, definitions, key points, and a brief recap."
  };
  try {
    const summary = await generateText(
      `Summarize this study material without adding unsupported facts.\n\nFormat: ${styles[style] || styles.balanced}\n\nMaterial:\n${text}`,
      "You are an accurate study-notes summarizer. Preserve names, numbers, definitions, and important nuance. Use readable Markdown."
    );
    res.json({ summary });
  } catch (error) {
    sendAIError(res, "Summarize", error);
  }
});

app.post("/api/quiz", requireAI, async (req, res) => {
  const topic = cleanText(req.body?.topic, 500);
  const count = Math.min(10, Math.max(3, Number.parseInt(req.body?.count, 10) || 5));
  const difficulty = ["easy", "medium", "hard"].includes(req.body?.difficulty) ? req.body.difficulty : "medium";
  if (!topic) return res.status(400).json({ error: "Enter a topic for your quiz." });
  try {
    const raw = await generateText(
      `Create ${count} multiple-choice questions about: ${topic}\nDifficulty: ${difficulty}.\nReturn ONLY valid JSON shaped exactly as {"questions":[{"question":"...","options":["...","...","...","..."],"answer":0,"explanation":"..."}]}. Use exactly four options, a zero-based answer index from 0 to 3, and one unambiguously correct answer per question.`,
      "You create fair, factual educational quizzes. Return only the requested JSON; do not use Markdown fences."
    );
    const json = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
    let parsed;
    try { parsed = JSON.parse(json); } catch { return res.status(502).json({ error: "The quiz generator returned an unexpected format. Please generate it again." }); }
    const questions = Array.isArray(parsed.questions) ? parsed.questions.slice(0, count).map(question => ({
      question: cleanText(question.question, 600),
      options: Array.isArray(question.options) ? question.options.slice(0, 4).map(option => cleanText(option, 300)) : [],
      answer: Number(question.answer),
      explanation: cleanText(question.explanation, 1000)
    })).filter(question => question.question && question.options.length === 4 && question.options.every(Boolean) && Number.isInteger(question.answer) && question.answer >= 0 && question.answer < 4) : [];
    if (!questions.length) return res.status(502).json({ error: "The quiz contained invalid questions. Please try again." });
    res.json({ questions });
  } catch (error) {
    sendAIError(res, "Quiz", error);
  }
});

app.use("/api", (_req, res) => res.status(404).json({ error: "API endpoint not found." }));
// Express 5 requires a named wildcard. This form also serves the site root.
app.get("/{*path}", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => {
  console.log(`Nova Study Assistant is running at http://localhost:${PORT}`);
  console.log(`Using ${MODEL} with ${FALLBACK_MODELS.length - 1} fallbacks and a ${MODEL_TIMEOUT_MS / 1000}-second per-model limit.`);
  if (!ai) console.log("Gemini API key missing: copy .env.example to .env and add GEMINI_API_KEY.");
});
